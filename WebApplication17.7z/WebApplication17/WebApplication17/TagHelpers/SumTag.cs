﻿using Microsoft.AspNetCore.Razor.Runtime.TagHelpers;
using Microsoft.AspNetCore.Razor.TagHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication17.TagHelpers
{
    // You may need to install the Microsoft.AspNetCore.Razor.Runtime package into your project
    [HtmlTargetElement("sum", TagStructure = TagStructure.NormalOrSelfClosing)]
    public class SumTag : TagHelper
    {
        [HtmlAttributeName("a")]
        public double a { get; set; }

        [HtmlAttributeName("b")]
        public double b { get; set; }

        [HtmlAttributeName("operator")]
        public Operator Operator { get; set; }
      
        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "";
            if (Operator == Operator.Add)
            {
                output.Content.SetHtmlContent((a + b).ToString());
            }
            else if (Operator == Operator.Sub)
            {
                output.Content.SetHtmlContent((a - b).ToString());
            }
            else if(Operator == Operator.Mul )
            {
                output.Content.SetHtmlContent((a * b).ToString());

            }
            else 
            {
                output.Content.SetHtmlContent((a / b).ToString());

            }
        }
        
    }
    public enum Operator
    {
        Add, Sub, Mul, Div
    }
}
